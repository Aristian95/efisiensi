<script src="<?php echo base_url();?>aset/js/jquery-1.9.1.min.js"></script>
    <script src="<?php echo base_url();?>aset/js/jquery-migrate-1.0.0.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery-ui-1.10.0.custom.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.ui.touch-punch.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/modernizr.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/bootstrap.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.cookie.js"></script>
    
        <script src='<?php echo base_url();?>aset/js/fullcalendar.min.js'></script>
    
        <script src='<?php echo base_url();?>aset/js/jquery.dataTables.min.js'></script>

        <script src="<?php echo base_url();?>aset/js/excanvas.js"></script>
    <script src="<?php echo base_url();?>aset/js/jquery.flot.js"></script>
    <script src="<?php echo base_url();?>aset/js/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url();?>aset/js/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url();?>aset/js/jquery.flot.resize.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.chosen.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.uniform.min.js"></script>
        
        <script src="<?php echo base_url();?>aset/js/jquery.cleditor.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.noty.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.elfinder.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.raty.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.iphone.toggle.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.uploadify-3.1.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.gritter.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.imagesloaded.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.masonry.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.knob.modified.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/jquery.sparkline.min.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/counter.js"></script>
    
        <script src="<?php echo base_url();?>aset/js/retina.js"></script>

        <script src="<?php echo base_url();?>aset/js/custom.js"></script>
    <!-- end: JavaScript-->
    
</body>
</html>